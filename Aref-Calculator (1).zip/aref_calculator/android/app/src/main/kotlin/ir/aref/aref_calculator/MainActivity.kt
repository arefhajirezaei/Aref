package ir.aref.aref_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
