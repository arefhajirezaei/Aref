import 'package:flutter/material.dart';
import '../state/calculator_controller.dart';
import '../theme/app_palette.dart';
import '../widgets/bubble_background.dart';
import '../widgets/calculator_keyboard.dart';
import '../widgets/glass_button.dart';
import '../widgets/glass_display.dart';

class CalculatorScreen extends StatelessWidget {
  final CalculatorController controller;
  const CalculatorScreen({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) {
        final palette = controller.darkMode
            ? AppPalette.darkPalette
            : AppPalette.lightPalette;
        return Scaffold(
          body: BubbleBackground(
            palette: palette,
            animated: controller.bubbleAnimation,
            child: SafeArea(
              child: LayoutBuilder(builder: (context, box) {
                final keyboardHeight =
                    (box.maxHeight * (controller.scientific ? 0.62 : 0.52))
                        .clamp(280.0, 560.0);
                return Column(children: [
                  // Header: brand + history + theme + scientific toggle.
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 12, 0),
                    child: Row(children: [
                      Text('Aref',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 2.5,
                              color: palette.resultColor)),
                      Text('  ✦',
                          style:
                              TextStyle(fontSize: 13, color: palette.glowCyan)),
                      const Spacer(),
                      IconButton(
                          tooltip: 'Scientific',
                          icon: Icon(Icons.functions, color: palette.iconColor),
                          onPressed: controller.toggleScientific),
                      IconButton(
                          tooltip: 'History',
                          icon: Icon(Icons.history, color: palette.iconColor),
                          onPressed: () => _showHistory(context, palette)),
                      IconButton(
                          tooltip: 'Background animation',
                          icon: Icon(
                              controller.bubbleAnimation
                                  ? Icons.bubble_chart
                                  : Icons.bubble_chart_outlined,
                              color: palette.iconColor),
                          onPressed: controller.toggleBubbles),
                      IconButton(
                          tooltip: 'Theme',
                          icon: Icon(
                              controller.darkMode
                                  ? Icons.light_mode_outlined
                                  : Icons.dark_mode_outlined,
                              color: palette.iconColor),
                          onPressed: controller.toggleTheme),
                    ]),
                  ),
                  // Display (focal point).
                  Expanded(
                      child: GlassDisplay(
                    expression: controller.expression,
                    result: controller.result,
                    error: controller.error,
                    palette: palette,
                  )),
                  // Keypad (glass layer in front of bubbles).
                  SizedBox(
                    height: keyboardHeight.toDouble(),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10, 4, 10, 12),
                      child: Column(children: [
                        if (controller.scientific)
                          Flexible(
                              flex: 3,
                              child: ScientificKeyboard(
                                  controller: controller, palette: palette)),
                        Flexible(
                            flex: 5,
                            child: CalculatorKeyboard(
                                controller: controller, palette: palette)),
                      ]),
                    ),
                  ),
                ]);
              }),
            ),
          ),
        );
      },
    );
  }

  void _showHistory(BuildContext context, AppPalette palette) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => GlassContainer(
        palette: palette,
        radius: const BorderRadius.vertical(top: Radius.circular(28)),
        child: SafeArea(
            child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Text('History',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: palette.resultColor)),
              const Spacer(),
              if (controller.history.isNotEmpty)
                TextButton(
                    onPressed: () {
                      controller.clearHistory();
                      Navigator.pop(context);
                    },
                    child: const Text('Clear')),
            ]),
            if (controller.history.isEmpty)
              Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('No calculations yet',
                      style: TextStyle(color: palette.expressionColor)))
            else
              Flexible(
                  child: ListView.builder(
                shrinkWrap: true,
                itemCount: controller.history.length,
                itemBuilder: (_, i) {
                  final h = controller.history[i];
                  return ListTile(
                    title: Text(h.expression,
                        style: TextStyle(
                            color: palette.expressionColor, fontSize: 14)),
                    subtitle: Text('= ${h.result}',
                        style: TextStyle(
                            color: palette.resultColor, fontSize: 19)),
                    onTap: () {
                      controller.useHistory(h);
                      Navigator.pop(context);
                    },
                  );
                },
              )),
          ]),
        )),
      ),
    );
  }
}
