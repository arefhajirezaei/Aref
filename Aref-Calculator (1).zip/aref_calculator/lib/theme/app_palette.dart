import 'package:flutter/material.dart';

/// Aref visual identity: Midnight Navy / Deep Indigo / Electric Blue /
/// Soft Violet / Ice Cyan / Pearl White. No unrelated colours anywhere.
class AppPalette {
  final bool dark;
  const AppPalette(this.dark);
  static const darkPalette = AppPalette(true);
  static const lightPalette = AppPalette(false);

  static const midnightNavy = Color(0xFF050A24);
  static const deepIndigo = Color(0xFF101A4E);
  static const electricBlue = Color(0xFF3E7BFA);
  static const softViolet = Color(0xFF8B7CFF);
  static const iceCyan = Color(0xFF67E8F9);
  static const pearlWhite = Color(0xFFF4F7FF);

  Color get bgTop => dark ? const Color(0xFF03061C) : const Color(0xFFF2F6FF);
  Color get bgMid => dark ? midnightNavy : const Color(0xFFE3ECFF);
  Color get bgBottom =>
      dark ? const Color(0xFF131044) : const Color(0xFFE9E4FF);
  Color get glowBlue =>
      dark ? const Color(0xFF2456D6) : const Color(0xFF9FC2FF);
  Color get glowViolet =>
      dark ? const Color(0xFF5B3FD4) : const Color(0xFFC4B5FD);
  Color get glowCyan =>
      dark ? const Color(0xFF0E7C9B) : const Color(0xFFA5F3FC);

  Color get resultColor => dark ? pearlWhite : const Color(0xFF0B1638);
  Color get expressionColor =>
      dark ? const Color(0xFFB9C4E8) : const Color(0xFF4A5B8A);
  Color get keyText => dark ? pearlWhite : const Color(0xFF10204D);
  Color get operatorText =>
      dark ? const Color(0xFFBFD9FF) : const Color(0xFF2B4FD8);
  Color get glassFill =>
      dark ? Colors.white.withOpacity(0.075) : Colors.white.withOpacity(0.38);
  Color get glassFillOperator => dark
      ? const Color(0xFF5B7CFF).withOpacity(0.20)
      : const Color(0xFF7C9CFF).withOpacity(0.28);
  Color get glassBorder =>
      dark ? Colors.white.withOpacity(0.22) : Colors.white.withOpacity(0.75);
  Color get glassShadow => dark
      ? Colors.black.withOpacity(0.38)
      : const Color(0xFF7A8FC7).withOpacity(0.28);
  Color get iconColor =>
      dark ? const Color(0xFFDCE7FF) : const Color(0xFF24366E);
}
