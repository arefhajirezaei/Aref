import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../engine/calculator_engine.dart';

class HistoryEntry {
  final String expression;
  final String result;
  const HistoryEntry(this.expression, this.result);
  Map<String, String> toJson() => {'e': expression, 'r': result};
  factory HistoryEntry.fromJson(Map<String, dynamic> j) =>
      HistoryEntry(j['e'] as String, j['r'] as String);
}

class CalculatorController extends ChangeNotifier {
  String expression = '';
  String result = '0';
  String? error;
  bool degrees = true;
  bool scientific = false;
  bool darkMode = true;
  bool bubbleAnimation = true;
  bool justEvaluated = false;
  List<HistoryEntry> history = [];

  CalculatorEngine get _engine => CalculatorEngine(degrees: degrees);

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      darkMode = p.getBool('darkMode') ?? true;
      degrees = p.getBool('degrees') ?? true;
      scientific = p.getBool('scientific') ?? false;
      bubbleAnimation = p.getBool('bubbleAnimation') ?? true;
      final raw = p.getString('history');
      if (raw != null) {
        history = (jsonDecode(raw) as List)
            .map((e) => HistoryEntry.fromJson(e as Map<String, dynamic>))
            .toList();
      }
    } catch (_) {/* storage unavailable: keep defaults */}
    _preview();
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('darkMode', darkMode);
      await p.setBool('degrees', degrees);
      await p.setBool('scientific', scientific);
      await p.setBool('bubbleAnimation', bubbleAnimation);
      await p.setString(
          'history', jsonEncode(history.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  void toggleTheme() {
    darkMode = !darkMode;
    _save();
    notifyListeners();
  }

  void toggleAngle() {
    degrees = !degrees;
    _preview();
    _save();
    notifyListeners();
  }

  void toggleScientific() {
    scientific = !scientific;
    _save();
    notifyListeners();
  }

  void toggleBubbles() {
    bubbleAnimation = !bubbleAnimation;
    _save();
    notifyListeners();
  }

  void input(String token) {
    error = null;
    if (justEvaluated) {
      const ops = {'+', '−', '-', '×', '÷', '^', '%'};
      if (!ops.contains(token)) expression = '';
      justEvaluated = false;
    }
    // Prevent two operators / two dots in a row.
    if (token == '.') {
      final tail = expression.split(RegExp(r'[+\-×÷(^*/ ]')).last;
      if (tail.contains('.')) return;
      if (expression.isEmpty || RegExp(r'[+\-×÷(^]$').hasMatch(expression)) {
        expression += '0';
      }
    }
    if (const {'+', '×', '÷', '^'}.contains(token) &&
        (expression.isEmpty || RegExp(r'[+\-×÷(^]$').hasMatch(expression))) {
      return;
    }
    expression += token;
    _preview();
    notifyListeners();
  }

  void backspace() {
    if (expression.isEmpty) return;
    // Remove function names atomically.
    for (final fn in [
      'asin(',
      'acos(',
      'atan(',
      'sin(',
      'cos(',
      'tan(',
      'log(',
      'ln(',
      'sqrt('
    ]) {
      if (expression.endsWith(fn)) {
        expression = expression.substring(0, expression.length - fn.length);
        _preview();
        notifyListeners();
        return;
      }
    }
    expression = expression.substring(0, expression.length - 1);
    justEvaluated = false;
    _preview();
    notifyListeners();
  }

  void clearAll() {
    expression = '';
    result = '0';
    error = null;
    justEvaluated = false;
    notifyListeners();
  }

  void negate() {
    if (expression.isEmpty) {
      expression = '-';
    } else if (expression.startsWith('-(') && expression.endsWith(')')) {
      expression = expression.substring(2, expression.length - 1);
    } else if (expression.startsWith('-')) {
      expression = expression.substring(1);
    } else {
      expression = '-($expression)';
    }
    _preview();
    notifyListeners();
  }

  void _preview() {
    if (expression.isEmpty) {
      result = '0';
      return;
    }
    try {
      result = formatNumber(_engine.evaluate(expression));
      error = null;
    } catch (e) {
      // Keep last valid result visible while typing; show error only on '='.
    }
  }

  void evaluate() {
    if (expression.isEmpty) return;
    try {
      final v = _engine.evaluate(expression);
      result = formatNumber(v);
      error = null;
      history.insert(0, HistoryEntry(expression, result));
      if (history.length > 100) history = history.sublist(0, 100);
      expression = result.replaceAll(',', '');
      justEvaluated = true;
      _save();
    } catch (e) {
      error = e is CalculatorException ? e.message : 'Error';
    }
    notifyListeners();
  }

  void useHistory(HistoryEntry e) {
    expression = e.result.replaceAll(',', '');
    result = e.result;
    justEvaluated = true;
    notifyListeners();
  }

  void clearHistory() {
    history = [];
    _save();
    notifyListeners();
  }
}
