import 'package:flutter/material.dart';
import 'screens/calculator_screen.dart';
import 'state/calculator_controller.dart';
import 'theme/app_palette.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = CalculatorController()..load();
  runApp(ArefApp(controller: controller));
}

/// Aref — Premium Liquid Glass Calculator.
class ArefApp extends StatelessWidget {
  final CalculatorController controller;
  const ArefApp({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: controller,
      builder: (context, _) => MaterialApp(
        title: 'Aref',
        debugShowCheckedModeBanner: false,
        themeMode: controller.darkMode ? ThemeMode.dark : ThemeMode.light,
        theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.light,
            scaffoldBackgroundColor: AppPalette.lightPalette.bgMid,
            fontFamily: 'Roboto'),
        darkTheme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            scaffoldBackgroundColor: AppPalette.darkPalette.bgMid,
            fontFamily: 'Roboto'),
        home: CalculatorScreen(controller: controller),
      ),
    );
  }
}
