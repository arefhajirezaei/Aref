import 'dart:math' as math;

/// Safe recursive-descent expression parser. NEVER uses eval.
/// Supports + - × ÷ ^ parentheses, implicit multiplication, %, factorial,
/// sin/cos/tan/asin/acos/atan, log/ln, sqrt, pi, e. Angle mode DEG/RAD.
class CalculatorException implements Exception {
  final String message;
  CalculatorException(this.message);
  @override
  String toString() => message;
}

class CalculatorEngine {
  final bool degrees;
  const CalculatorEngine({this.degrees = true});

  double evaluate(String input) {
    var s = input
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll('–', '-')
        .replaceAll(',', '')
        .replaceAll(' ', '');
    if (s.isEmpty) throw CalculatorException('Empty expression');
    final p = _Parser(s, degrees);
    final v = p.parseExpression();
    p.expectEnd();
    if (v.isNaN || v.isInfinite) throw CalculatorException('Error');
    return v;
  }
}

class _Parser {
  final String s;
  final bool degrees;
  int pos = 0;
  _Parser(this.s, this.degrees);

  String? get _peek => pos < s.length ? s[pos] : null;
  bool _eat(String c) {
    if (_peek == c) {
      pos++;
      return true;
    }
    return false;
  }

  void expectEnd() {
    if (pos != s.length) throw CalculatorException('Unexpected: ${s[pos]}');
  }

  double parseExpression() {
    var v = _parseTerm();
    while (true) {
      if (_eat('+')) {
        v += _parseTerm();
      } else if (_eat('-')) {
        v -= _parseTerm();
      } else {
        return v;
      }
    }
  }

  double _parseTerm() {
    var v = _parseFactor();
    while (true) {
      if (_eat('*')) {
        v = _mul(v, _parseFactor());
      } else if (_eat('/')) {
        final d = _parseFactor();
        if (d == 0) throw CalculatorException('Cannot divide by zero');
        v /= d;
      } else if (_peek != null &&
          (_isDigit(_peek!) || _peek == '(' || _isLetter(_peek!))) {
        v = _mul(v, _parseFactor()); // implicit multiplication: 2(3), 2pi
      } else {
        return v;
      }
    }
  }

  double _mul(double a, double b) => a * b;

  double _parseFactor() {
    if (_eat('-')) return -_parseFactor();
    if (_eat('+')) return _parseFactor();
    var base = _parsePostfix();
    if (_eat('^')) {
      final exp = _parseFactor(); // right-associative
      base = math.pow(base, exp).toDouble();
    }
    return base;
  }

  double _parsePostfix() {
    var v = _parsePrimary();
    while (true) {
      if (_eat('%')) {
        v /= 100;
      } else if (_eat('!')) {
        v = _factorial(v);
      } else {
        return v;
      }
    }
  }

  double _factorial(double v) {
    if (v < 0 || v != v.roundToDouble() || v > 170) {
      throw CalculatorException('Invalid factorial');
    }
    var r = 1.0;
    for (var i = 2; i <= v.toInt(); i++) {
      r *= i;
    }
    return r;
  }

  double _parsePrimary() {
    final c = _peek;
    if (c == null) throw CalculatorException('Unexpected end');
    if (_eat('(')) {
      final v = parseExpression();
      if (!_eat(')')) throw CalculatorException('Missing )');
      return v;
    }
    if (_isDigit(c) || c == '.') return _parseNumber();
    if (_isLetter(c)) {
      final name = _parseName();
      switch (name) {
        case 'pi':
        case 'π':
          return math.pi;
        case 'e':
          return math.e;
        case 'sin':
        case 'cos':
        case 'tan':
        case 'asin':
        case 'acos':
        case 'atan':
        case 'log':
        case 'ln':
        case 'sqrt':
          if (!_eat('(')) throw CalculatorException('Missing ( after $name');
          final arg = parseExpression();
          if (!_eat(')')) throw CalculatorException('Missing )');
          return _apply(name, arg);
        default:
          throw CalculatorException('Unknown: $name');
      }
    }
    throw CalculatorException('Unexpected: $c');
  }

  double _apply(String fn, double x) {
    double rad(double d) => degrees ? d * math.pi / 180 : d;
    double deg(double r) => degrees ? r * 180 / math.pi : r;
    switch (fn) {
      case 'sin':
        return math.sin(rad(x));
      case 'cos':
        return math.cos(rad(x));
      case 'tan':
        final r = math.tan(rad(x));
        if (r.abs() > 1e15) throw CalculatorException('Error');
        return r;
      case 'asin':
        if (x < -1 || x > 1) throw CalculatorException('Error');
        return deg(math.asin(x));
      case 'acos':
        if (x < -1 || x > 1) throw CalculatorException('Error');
        return deg(math.acos(x));
      case 'atan':
        return deg(math.atan(x));
      case 'log':
        if (x <= 0) throw CalculatorException('Error');
        return math.log(x) / math.ln10;
      case 'ln':
        if (x <= 0) throw CalculatorException('Error');
        return math.log(x);
      case 'sqrt':
        if (x < 0) throw CalculatorException('Error');
        return math.sqrt(x);
      default:
        throw CalculatorException('Unknown function');
    }
  }

  double _parseNumber() {
    final start = pos;
    var dot = false;
    while (pos < s.length && (_isDigit(s[pos]) || s[pos] == '.')) {
      if (s[pos] == '.') {
        if (dot) throw CalculatorException('Invalid number');
        dot = true;
      }
      pos++;
    }
    // exponent notation, e.g. 1e3 (only when digits follow)
    if (pos < s.length &&
        (s[pos] == 'e') &&
        pos + 1 < s.length &&
        (_isDigit(s[pos + 1]) || s[pos + 1] == '-' || s[pos + 1] == '+')) {
      // avoid consuming constant 'e' when it is not exponent: only if previous char is digit
      pos++;
      if (s[pos] == '-' || s[pos] == '+') pos++;
      while (pos < s.length && _isDigit(s[pos])) {
        pos++;
      }
    }
    final v = double.tryParse(s.substring(start, pos));
    if (v == null) throw CalculatorException('Invalid number');
    return v;
  }

  String _parseName() {
    final start = pos;
    while (pos < s.length && _isLetter(s[pos])) {
      pos++;
    }
    if (pos < s.length && s[pos] == 'π') {
      pos++;
      return 'π';
    }
    return s.substring(start, pos);
  }

  bool _isDigit(String c) => c.codeUnitAt(0) >= 48 && c.codeUnitAt(0) <= 57;
  bool _isLetter(String c) {
    final u = c.codeUnitAt(0);
    return (u >= 97 && u <= 122) || (u >= 65 && u <= 90) || c == 'π';
  }
}

/// Formats results: grouped thousands, no trailing zeros, sci notation for extremes.
String formatNumber(double v) {
  if (v == 0) {
    return '0';
  }
  if (v.abs() >= 1e16 || (v.abs() < 1e-9 && v != 0)) {
    return v.toStringAsExponential(8).replaceAll('e+', 'e');
  }
  var s = v.toStringAsFixed(10);
  if (s.contains('.')) {
    s = s.replaceAll(RegExp(r'0+$'), '').replaceAll(RegExp(r'\.$'), '');
  }
  final neg = s.startsWith('-');
  if (neg) s = s.substring(1);
  final parts = s.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (var i = 0; i < intPart.length; i++) {
    if (i > 0 && (intPart.length - i) % 3 == 0) buf.write(',');
    buf.write(intPart[i]);
  }
  final out =
      parts.length > 1 ? '${buf.toString()}.${parts[1]}' : buf.toString();
  return neg ? '-$out' : out;
}

String groupExpression(String expr) {
  // Light grouping for display of integer runs inside an expression.
  return expr.replaceAllMapped(RegExp(r'\d{4,}'), (m) {
    final t = m.group(0)!;
    final b = StringBuffer();
    for (var i = 0; i < t.length; i++) {
      if (i > 0 && (t.length - i) % 3 == 0) b.write(',');
      b.write(t[i]);
    }
    return b.toString();
  });
}
