import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_palette.dart';

enum GlassButtonKind { number, operator, danger, equals }

/// Reusable frosted-glass container (single BackdropFilter, use sparingly).
class GlassContainer extends StatelessWidget {
  final Widget child;
  final BorderRadius radius;
  final AppPalette palette;
  const GlassContainer(
      {super.key,
      required this.child,
      required this.palette,
      this.radius = const BorderRadius.all(Radius.circular(28))});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: radius,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: radius,
            color: palette.glassFill,
            border: Border.all(color: palette.glassBorder.withOpacity(0.35)),
          ),
          child: child,
        ),
      ),
    );
  }
}

/// Liquid Glass button: translucent fill, top-light reflection, thin bright
/// border, soft shadow, and a fast press animation (scale + brightness +
/// light sweep). The equals variant uses the blue→violet signature gradient.
class GlassButton extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final AppPalette palette;
  final GlassButtonKind kind;
  final double fontSize;
  const GlassButton({
    super.key,
    required this.label,
    required this.onTap,
    required this.palette,
    this.kind = GlassButtonKind.number,
    this.fontSize = 26,
  });

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 110),
      reverseDuration: const Duration(milliseconds: 180));

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.palette;
    final reduce = MediaQuery.of(context).disableAnimations;
    final isEq = widget.kind == GlassButtonKind.equals;
    final isOp = widget.kind == GlassButtonKind.operator;
    final isDanger = widget.kind == GlassButtonKind.danger;

    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final press = reduce ? 0.0 : _c.value; // 0 rest, 1 pressed
        final scale = 1 - 0.07 * press;
        return Transform.scale(
          scale: scale,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: (_) => _c.forward(),
            onTapCancel: () => _c.reverse(),
            onTapUp: (_) {
              _c.reverse();
              widget.onTap();
            },
            child: Container(
              margin: const EdgeInsets.all(5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                gradient: isEq
                    ? const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                            AppPalette.electricBlue,
                            AppPalette.softViolet
                          ])
                    : LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                            Colors.white.withOpacity(
                                (isOp ? 0.22 : 0.14) + 0.14 * press),
                            (isOp ? p.glassFillOperator : p.glassFill),
                            Colors.white.withOpacity(0.03),
                          ],
                        stops: const [
                            0,
                            0.55,
                            1
                          ]),
                border: Border.all(
                    color:
                        isEq ? Colors.white.withOpacity(0.55) : p.glassBorder,
                    width: 1.1),
                boxShadow: [
                  BoxShadow(
                      color: p.glassShadow,
                      blurRadius: 14,
                      offset: const Offset(0, 7)),
                  if (isEq)
                    BoxShadow(
                        color: AppPalette.softViolet
                            .withOpacity(0.35 + 0.25 * press),
                        blurRadius: 22 + 14 * press,
                        offset: const Offset(0, 6)),
                  // Top inner light reflection.
                  BoxShadow(
                      color: Colors.white.withOpacity(0.10 + 0.10 * press),
                      blurRadius: 6,
                      offset: const Offset(0, -2)),
                ],
              ),
              child: Stack(alignment: Alignment.center, children: [
                // Light sweep highlight while pressed.
                Positioned(
                    top: 4,
                    left: 10,
                    right: 10,
                    child: Container(
                        height: 14,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: LinearGradient(colors: [
                              Colors.white.withOpacity(0.22 + 0.22 * press),
                              Colors.white.withOpacity(0),
                            ])))),
                Text(widget.label,
                    style: TextStyle(
                      fontSize: widget.fontSize,
                      fontWeight:
                          isEq || isOp ? FontWeight.w600 : FontWeight.w400,
                      color: isEq
                          ? Colors.white
                          : isDanger
                              ? const Color(0xFFFF9DB0)
                              : isOp
                                  ? p.operatorText
                                  : p.keyText,
                      shadows: [
                        Shadow(
                            color:
                                Colors.black.withOpacity(p.dark ? 0.35 : 0.08),
                            blurRadius: 6,
                            offset: const Offset(0, 2))
                      ],
                    )),
              ]),
            ),
          ),
        );
      },
    );
  }
}
