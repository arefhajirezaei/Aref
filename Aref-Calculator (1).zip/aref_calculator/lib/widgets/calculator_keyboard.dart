import 'package:flutter/material.dart';
import '../state/calculator_controller.dart';
import '../theme/app_palette.dart';
import 'glass_button.dart';

class _Key {
  final String label, token;
  final GlassButtonKind kind;
  const _Key(this.label, this.token, [this.kind = GlassButtonKind.number]);
}

/// Standard Liquid Glass keypad (5 rows x 4).
class CalculatorKeyboard extends StatelessWidget {
  final CalculatorController controller;
  final AppPalette palette;
  const CalculatorKeyboard(
      {super.key, required this.controller, required this.palette});

  @override
  Widget build(BuildContext context) {
    final c = controller;
    final rows = <List<_Key>>[
      [
        const _Key('AC', 'AC', GlassButtonKind.danger),
        const _Key('±', '±'),
        const _Key('%', '%', GlassButtonKind.operator),
        const _Key('÷', '÷', GlassButtonKind.operator)
      ],
      [
        const _Key('7', '7'),
        const _Key('8', '8'),
        const _Key('9', '9'),
        const _Key('×', '×', GlassButtonKind.operator)
      ],
      [
        const _Key('4', '4'),
        const _Key('5', '5'),
        const _Key('6', '6'),
        const _Key('−', '−', GlassButtonKind.operator)
      ],
      [
        const _Key('1', '1'),
        const _Key('2', '2'),
        const _Key('3', '3'),
        const _Key('+', '+', GlassButtonKind.operator)
      ],
      [
        const _Key('⌫', '⌫'),
        const _Key('0', '0'),
        const _Key('.', '.'),
        const _Key('=', '=', GlassButtonKind.equals)
      ],
    ];
    return Column(children: [
      for (final row in rows)
        Expanded(
            child: Row(children: [
          for (final k in row)
            Expanded(
                child: GlassButton(
              label: k.label,
              palette: palette,
              kind: k.kind,
              onTap: () {
                switch (k.token) {
                  case 'AC':
                    c.clearAll();
                    break;
                  case '⌫':
                    c.backspace();
                    break;
                  case '±':
                    c.negate();
                    break;
                  case '=':
                    c.evaluate();
                    break;
                  default:
                    c.input(k.token);
                }
              },
            )),
        ])),
    ]);
  }
}

/// Scientific row set shown above the standard keypad when enabled.
class ScientificKeyboard extends StatelessWidget {
  final CalculatorController controller;
  final AppPalette palette;
  const ScientificKeyboard(
      {super.key, required this.controller, required this.palette});

  @override
  Widget build(BuildContext context) {
    final c = controller;
    Widget btn(String label, String token, {VoidCallback? action}) => Expanded(
        child: GlassButton(
            label: label,
            palette: palette,
            fontSize: 15,
            kind: GlassButtonKind.operator,
            onTap: action ?? () => c.input(token)));
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Row(children: [
        btn(c.degrees ? 'DEG' : 'RAD', '', action: c.toggleAngle),
        btn('sin', 'sin('),
        btn('cos', 'cos('),
        btn('tan', 'tan('),
        btn('(', '('),
        btn(')', ')'),
      ]),
      Row(children: [
        btn('√', 'sqrt('),
        btn('x²', '^2'),
        btn('xʸ', '^'),
        btn('log', 'log('),
        btn('ln', 'ln('),
        btn('π', 'π'),
      ]),
      Row(children: [
        btn('asin', 'asin('),
        btn('acos', 'acos('),
        btn('atan', 'atan('),
        btn('e', 'e'),
        btn('x!', '!'),
        btn('1/x', '^(-1)'),
      ]),
    ]);
  }
}
