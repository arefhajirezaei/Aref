import 'package:flutter/material.dart';
import '../engine/calculator_engine.dart';
import '../theme/app_palette.dart';

/// Minimal luxury display: small grey expression on top, huge pearl-white
/// result below. Font size adapts to length; long expressions scroll.
class GlassDisplay extends StatelessWidget {
  final String expression;
  final String result;
  final String? error;
  final AppPalette palette;
  const GlassDisplay(
      {super.key,
      required this.expression,
      required this.result,
      required this.palette,
      this.error});

  double _resultFontSize(String text, double width) {
    final len = text.length.clamp(1, 30);
    final byLength = 64 - (len - 7).clamp(0, 20) * 2.2;
    return (width / (len * 0.58)).clamp(26, byLength.clamp(26, 64)).toDouble();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final shownResult = error ?? result;
      return Padding(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            SizedBox(
              height: 30,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                reverse: true,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    expression.isEmpty ? ' ' : groupExpression(expression),
                    maxLines: 1,
                    style: TextStyle(
                        fontSize: 19,
                        color: palette.expressionColor,
                        fontWeight: FontWeight.w400,
                        letterSpacing: 0.6),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 4),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 160),
              transitionBuilder: (child, anim) => FadeTransition(
                  opacity: anim,
                  child: SlideTransition(
                      position: Tween<Offset>(
                              begin: const Offset(0, 0.08), end: Offset.zero)
                          .animate(anim),
                      child: child)),
              child: Align(
                key: ValueKey(shownResult),
                alignment: Alignment.centerRight,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  alignment: Alignment.centerRight,
                  child: Text(
                    shownResult,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize:
                          _resultFontSize(shownResult, constraints.maxWidth),
                      fontWeight: FontWeight.w300,
                      color: error != null
                          ? const Color(0xFFFF9DB0)
                          : palette.resultColor,
                      shadows: [
                        Shadow(
                            color: AppPalette.iceCyan
                                .withOpacity(palette.dark ? 0.25 : 0.10),
                            blurRadius: 18)
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}
