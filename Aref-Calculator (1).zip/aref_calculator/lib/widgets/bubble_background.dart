import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_palette.dart';

/// A single 3D glass bubble specification.
class FloatingGlassBubble {
  final double x, y, radius, speed, phase, drift;
  final int tint; // 0 ice-blue, 1 electric blue, 2 violet
  const FloatingGlassBubble(this.x, this.y, this.radius, this.speed, this.phase,
      this.drift, this.tint);
}

/// Animated cinematic background: deep gradient -> soft glows -> far bubbles
/// -> near bubbles. One AnimationController drives everything (perf-friendly).
/// Set [animated]=false for a static, battery-saving frame.
class BubbleBackground extends StatefulWidget {
  final AppPalette palette;
  final bool animated;
  final Widget child;
  const BubbleBackground(
      {super.key,
      required this.palette,
      required this.animated,
      required this.child});

  @override
  State<BubbleBackground> createState() => _BubbleBackgroundState();
}

class _BubbleBackgroundState extends State<BubbleBackground>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _c;

  static const _bubbles = <FloatingGlassBubble>[
    FloatingGlassBubble(-0.08, 0.10, 120, 0.7, 0.0, 18, 1),
    FloatingGlassBubble(0.92, 0.04, 88, 0.9, 1.7, 14, 2),
    FloatingGlassBubble(0.78, 0.52, 150, 0.5, 3.1, 22, 0),
    FloatingGlassBubble(0.10, 0.62, 70, 1.1, 2.2, 12, 2),
    FloatingGlassBubble(0.55, 0.22, 42, 1.4, 0.8, 10, 0),
    FloatingGlassBubble(0.30, 0.38, 26, 1.8, 4.0, 8, 1),
    FloatingGlassBubble(0.88, 0.80, 34, 1.6, 5.2, 9, 0),
    FloatingGlassBubble(0.18, 0.88, 52, 1.2, 2.9, 11, 1),
    FloatingGlassBubble(0.62, 0.72, 18, 2.2, 1.1, 7, 2),
    FloatingGlassBubble(0.42, 0.05, 20, 2.0, 3.8, 7, 0),
    FloatingGlassBubble(1.05, 0.38, 64, 0.8, 5.8, 15, 1),
    FloatingGlassBubble(-0.05, 0.35, 36, 1.5, 0.4, 9, 0),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 48))
      ..repeat();
    if (!widget.animated) _c.stop();
  }

  @override
  void didUpdateWidget(BubbleBackground old) {
    super.didUpdateWidget(old);
    if (widget.animated && !_c.isAnimating) {
      _c.repeat();
    } else if (!widget.animated) {
      _c.stop();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Pause background motion when the app is not visible (battery).
    if (state == AppLifecycleState.resumed) {
      if (widget.animated && !_c.isAnimating) _c.repeat();
    } else {
      _c.stop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.of(context).disableAnimations;
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => CustomPaint(
        painter: _BubblePainter(
          palette: widget.palette,
          t: reduceMotion || !widget.animated ? 0.25 : _c.value * math.pi * 2,
          bubbles: _bubbles,
        ),
        child: child,
      ),
      child: widget.child,
    );
  }
}

class _BubblePainter extends CustomPainter {
  final AppPalette palette;
  final double t;
  final List<FloatingGlassBubble> bubbles;
  _BubblePainter(
      {required this.palette, required this.t, required this.bubbles});

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    // Layer 1: deep gradient background.
    canvas.drawRect(
        rect,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [palette.bgTop, palette.bgMid, palette.bgBottom],
            stops: const [0, 0.55, 1],
          ).createShader(rect));

    // Layer 2: cinematic soft glows (no hard edges).
    void glow(double fx, double fy, double r, Color c, double a) {
      final center = Offset(size.width * fx, size.height * fy);
      canvas.drawCircle(
          center,
          r,
          Paint()
            ..shader =
                RadialGradient(colors: [c.withOpacity(a), c.withOpacity(0)])
                    .createShader(Rect.fromCircle(center: center, radius: r)));
    }

    glow(0.92, 0.02, size.width * 0.75, palette.glowBlue,
        palette.dark ? 0.50 : 0.55);
    glow(0.02, 0.98, size.width * 0.80, palette.glowViolet,
        palette.dark ? 0.45 : 0.50);
    glow(0.55, 0.45, size.width * 0.55, palette.glowCyan,
        palette.dark ? 0.16 : 0.22);

    // Layers 3-4: far (large) then near (small) 3D glass bubbles.
    final sorted = [...bubbles]..sort((a, b) => b.radius.compareTo(a.radius));
    for (final b in sorted) {
      final wobble = math.sin(t * b.speed + b.phase);
      final center = Offset(
        size.width * b.x + math.cos(t * b.speed * 0.7 + b.phase) * b.drift,
        size.height * b.y + wobble * b.drift * 0.8,
      );
      _drawBubble(canvas, center, b.radius, b.tint, 0.92 + 0.08 * wobble);
    }
  }

  void _drawBubble(
      Canvas canvas, Offset c, double r, int tint, double lightPulse) {
    final tintColor = switch (tint) {
      1 => AppPalette.electricBlue,
      2 => AppPalette.softViolet,
      _ => AppPalette.iceCyan,
    };
    final sphere = Rect.fromCircle(center: c, radius: r);
    // Soft shadow opposite the (top-left) key light.
    canvas.drawCircle(
        c + Offset(r * 0.10, r * 0.16),
        r * 0.98,
        Paint()
          ..color = Colors.black.withOpacity(palette.dark ? 0.28 : 0.10)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18));
    // Glass body: radial gradient, brighter toward top-left light.
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = RadialGradient(
            center: const Alignment(-0.45, -0.55),
            radius: 1.15,
            colors: [
              Colors.white
                  .withOpacity((palette.dark ? 0.34 : 0.65) * lightPulse),
              tintColor.withOpacity(palette.dark ? 0.20 : 0.28),
              tintColor.withOpacity(palette.dark ? 0.10 : 0.14),
              Colors.white.withOpacity(0.03),
            ],
            stops: const [0, 0.38, 0.72, 1],
          ).createShader(sphere));
    // Faint environmental colour reflection (lower-right rim).
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.10
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10)
          ..shader = SweepGradient(
            startAngle: 0.4,
            endAngle: 2.0,
            colors: [
              tintColor.withOpacity(0),
              tintColor.withOpacity(0.20),
              tintColor.withOpacity(0)
            ],
          ).createShader(sphere));
    // Crisp thin glass border.
    canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.1
          ..color = Colors.white.withOpacity(palette.dark ? 0.30 : 0.65));
    // Primary specular highlight (top-left, follows key light).
    final hl = c + Offset(-r * 0.38, -r * 0.46);
    canvas.drawOval(
        Rect.fromCenter(center: hl, width: r * 0.52, height: r * 0.30),
        Paint()
          ..shader = RadialGradient(colors: [
            Colors.white.withOpacity(0.85 * lightPulse),
            Colors.white.withOpacity(0),
          ]).createShader(Rect.fromCircle(center: hl, radius: r * 0.30))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    // Tiny sharp sparkle near the highlight.
    canvas.drawCircle(c + Offset(-r * 0.52, -r * 0.30), r * 0.055,
        Paint()..color = Colors.white.withOpacity(0.9 * lightPulse));
    // Bottom inner glow: subtle refraction bounce.
    final bounce = c + Offset(r * 0.18, r * 0.48);
    canvas.drawOval(
        Rect.fromCenter(center: bounce, width: r * 0.9, height: r * 0.36),
        Paint()
          ..shader = RadialGradient(colors: [
            tintColor.withOpacity(0.22),
            tintColor.withOpacity(0),
          ]).createShader(Rect.fromCircle(center: bounce, radius: r * 0.45))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
  }

  @override
  bool shouldRepaint(_BubblePainter old) =>
      old.t != t || old.palette.dark != palette.dark;
}
