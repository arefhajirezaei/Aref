# Aref — Premium Liquid Glass Calculator

ماشین‌حساب اندرویدی لوکس با Flutter/Dart، الهام‌گرفته از Liquid Glass، با هویت مستقل:
پس‌زمینه سرمه‌ای عمیق (Midnight Navy → Deep Indigo)، حباب‌های شیشه‌ای سه‌بعدی آبی/بنفش
با انعکاس نور، دکمه‌های Liquid Glass و نمایشگر مینیمال با نتیجه بزرگ سفید مرواریدی.

## Features
- **3D glass bubbles**: `CustomPainter` + radial/sweep gradients, specular highlight,
  sparkle, soft shadow, refraction bounce, thin border — one shared
  `AnimationController` (48s loop), paused in background / when disabled /
  when the OS requests reduced motion.
- **GlassButton**: translucent fill, top-light reflection, press animation
  (scale + brightness + light sweep); equals key = Electric Blue → Soft Violet
  gradient with a soft glow pulse. AC is tinted distinctly.
- **GlassDisplay**: small grey expression (horizontal scroll), huge adaptive
  pearl-white result with `AnimatedSwitcher`.
- **Themes**: full dark & light palettes, animated, persisted.
- **Calculator**: + − × ÷, %, decimal, ±, backspace, parentheses & precedence,
  implicit multiplication, powers, factorial — plus scientific mode
  (sin/cos/tan & inverses, log/ln, √, π, e) with DEG/RAD.
- **Safe parser**: hand-written recursive-descent parser in
  `lib/engine/calculator_engine.dart` — no `eval`, ever. Division-by-zero and
  domain errors surface as friendly messages.
- **History** (100 entries) and settings persisted with `shared_preferences`.

## Structure
```
lib/main.dart                        app entry (Aref)
lib/theme/app_palette.dart           single colour identity (dark/light)
lib/engine/calculator_engine.dart    safe parser + number formatting
lib/state/calculator_controller.dart state, history, persistence
lib/widgets/bubble_background.dart   BubbleBackground + FloatingGlassBubble
lib/widgets/glass_button.dart        GlassButton + GlassContainer
lib/widgets/glass_display.dart       GlassDisplay
lib/widgets/calculator_keyboard.dart CalculatorKeyboard + ScientificKeyboard
lib/screens/calculator_screen.dart   layout, header, history sheet
test/                                engine unit tests + widget tests
```

## Run / Test / Build
```bash
flutter pub get
flutter analyze     # must be clean
flutter test        # engine + widget tests
flutter build apk --release
# output: build/app/outputs/flutter-apk/app-release.apk
```

> Note: `android/gradle.properties` caps Gradle/Kotlin memory
> (-Xmx1300m) so the build also works on low-RAM machines/CI.
