import 'package:aref_calculator/engine/calculator_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const deg = CalculatorEngine(degrees: true);
  const rad = CalculatorEngine(degrees: false);

  group('arithmetic & precedence', () {
    test('addition', () => expect(deg.evaluate('2+3'), 5));
    test('precedence', () => expect(deg.evaluate('2+3*4'), 14));
    test('parentheses', () => expect(deg.evaluate('(2+3)*4'), 20));
    test('division', () => expect(deg.evaluate('10/4'), 2.5));
    test('power right-assoc', () => expect(deg.evaluate('2^3^2'), 512));
    test('implicit multiplication', () => expect(deg.evaluate('2(3+1)'), 8));
    test('unary minus', () => expect(deg.evaluate('-5+3'), -2));
    test('percent postfix', () => expect(deg.evaluate('50%'), 0.5));
    test('factorial', () => expect(deg.evaluate('5!'), 120));
    test('unicode operators', () => expect(deg.evaluate('6×7'), 42));
    test('spec example 128×24', () => expect(deg.evaluate('128×24'), 3072));
  });

  group('scientific', () {
    test('sin DEG', () => expect(deg.evaluate('sin(90)'), closeTo(1, 1e-9)));
    test('sin RAD',
        () => expect(rad.evaluate('sin(1.57079632679)'), closeTo(1, 1e-9)));
    test('sqrt', () => expect(deg.evaluate('sqrt(16)'), 4));
    test('log10', () => expect(deg.evaluate('log(1000)'), closeTo(3, 1e-9)));
    test('ln(e)', () => expect(deg.evaluate('ln(e)'), closeTo(1, 1e-9)));
    test('pi constant',
        () => expect(deg.evaluate('2*pi'), closeTo(6.283185307, 1e-9)));
  });

  group('errors (safe parser, no eval)', () {
    test(
        'divide by zero',
        () => expect(
            () => deg.evaluate('1/0'), throwsA(isA<CalculatorException>())));
    test(
        'sqrt negative',
        () => expect(() => deg.evaluate('sqrt(-1)'),
            throwsA(isA<CalculatorException>())));
    test(
        'unbalanced paren',
        () => expect(
            () => deg.evaluate('(2+3'), throwsA(isA<CalculatorException>())));
    test(
        'trailing junk',
        () => expect(
            () => deg.evaluate('2+'), throwsA(isA<CalculatorException>())));
  });

  group('formatting', () {
    test('thousands separator', () => expect(formatNumber(3072), '3,072'));
    test('decimal trimmed', () => expect(formatNumber(2.5), '2.5'));
    test('negative grouped',
        () => expect(formatNumber(-1234567.5), '-1,234,567.5'));
  });
}
