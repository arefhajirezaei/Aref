import 'package:aref_calculator/main.dart';
import 'package:aref_calculator/state/calculator_controller.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Aref renders, calculates 7×8=56', (tester) async {
    final c = CalculatorController();
    await tester.pumpWidget(ArefApp(controller: c));
    await tester.pump();
    expect(find.text('Aref'), findsOneWidget);
    expect(find.text('0'), findsWidgets);
    await tester.tap(find.text('7'));
    await tester.pump();
    await tester.tap(find.text('×'));
    await tester.pump();
    await tester.tap(find.text('8'));
    await tester.pump();
    await tester.tap(find.text('='));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('56'), findsWidgets);
    expect(c.result, '56');
  });

  testWidgets('AC clears', (tester) async {
    final c = CalculatorController();
    await tester.pumpWidget(ArefApp(controller: c));
    await tester.pump();
    await tester.tap(find.text('9'));
    await tester.pump();
    await tester.tap(find.text('AC'));
    await tester.pump();
    expect(c.expression, '');
    expect(c.result, '0');
  });
}
